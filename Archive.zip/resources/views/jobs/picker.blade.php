



  <script>
  $( function() {
    $( "#datepicker" ).datepicker();
  } );
  $( function() {
    $( "#datepicker2" ).datepicker();
  } );
  </script>



  Date: <input type="text" size="8" id="datepicker"> -  <input type="text" size="8" id="datepicker2"><br>
