<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Welcome, <?php echo e(Auth::user()->first); ?>!</div>

                <div class="panel-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <a href="sub"> Continue to Substitute View</a><br><br>
                    <a href="staff"> Continue to Staff Member View</a><br><br>
                    <a href="school"> Continue to SchoolDay View</a><br><br>
                    <a href="admin"> Continue to Admin View</a><br><br>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>